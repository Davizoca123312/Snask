# Snask - Documentação da Linguagem

Snask é uma linguagem de programação simples e expressiva, projetada para facilitar o aprendizado e prototipagem de ideias. Abaixo está a descrição de todas as instruções suportadas atualmente.

---

## ✨ Variáveis e Constantes

- `make nome = valor` — Cria uma variável.
- `set nome = novo_valor` — Altera o valor de uma variável.
- `zap nome` — Remove a variável do ambiente.
- `keep nome = valor` — Define uma constante (imutabilidade não implementada).

---

## 📢 Entrada e Saída

- `shoo valor` — Mostra um valor no terminal.
- `grab nome` — Lê um valor como string.
- `grabnum nome` — Lê um valor numérico (inteiro).
- `grabtxt nome` — Lê texto e armazena como string.

---

## 📊 Operadores

- `a + b` — Soma.
- `a - b` — Subtração.
- `a * b` — Multiplicação.
- `a / b` — Divisão.
- `a is b` — Igualdade.
- `a aint b` — Diferença.
- `a == b` — Igualdade (mesma função de `is`).

---

## 🥷 Conversão de Tipos

- `convert var to int` — Converte string para inteiro.
- `convert var to str` — Converte inteiro para string.

---

## ⏳ Controle de Fluxo

- `when condicao:` — Executa blocos se a condição for verdadeira.
- `spin condicao:` — Loop enquanto a condição for verdadeira.
- `loopy:` — Loop infinito.
- `breaky` — Encerra o loop.
- `skipit` — Pula a iteração (não implementado).

---

## 💪 Funções

- `craft nome:` — Declaração de função.
- `nome` — Chamada de função.
- `back valor` — Retorno de valor da função.

---

## 📁 Listas (packs)

- `pack nome = [1, 2, 3]` — Cria uma lista.
- `packadd nome valor` — Adiciona à lista.
- `packget nome indice` — Acessa item da lista.

---

## 📖 Dicionários (boxes)

- `box nome = {chave: valor}` — Cria um dicionário.
- `boxput nome chave valor` — Define valor para chave.
- `boxget nome chave` — Obtém valor da chave.

---

## ⏱ Espera

- `snooze segundos` — Pausa a execução.

---

## ✏️ Comentários

- `// qualquer coisa` — Comentário de linha (ignorado pelo interpretador).

---

## 📓 Exemplo Completo

```snask
make primeiro = 0
make segundo = 0

grabnum primeiro
grabnum segundo

make soma = primeiro + segundo
convert soma to str

shoo "A soma é: " + soma  // Exibe a soma formatada como texto
```

Esse exemplo recebe dois números do usuário, soma, converte para string e exibe formatado.

---

Feito com ❤þ usando a linguagem **Snask**.

