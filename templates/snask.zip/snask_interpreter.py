from lark import Transformer, Lark
import time
import os

class SnaskInterpreter(Transformer):
    def __init__(self, parser=None):
        self.env = {}
        self.functions = {}
        self.returning = False
        self.return_value = None
        self.parser = parser  # necessário para interpretar outras libs

    # VARIÁVEIS E CONSTANTES
    def var_decl(self, items):
        name = str(items[0])
        value = self._resolve(items[1])
        self.env[name] = value

    def var_set(self, items):
        name = str(items[0])
        value = self._resolve(items[1])
        self.env[name] = value

    def var_zap(self, items):
        name = str(items[0])
        self.env.pop(name, None)

    def const_decl(self, items):
        name = str(items[0])
        value = self._resolve(items[1])
        self.env[name] = value

    # I/O
    def print_stmt(self, items):
        print(self._resolve(items[0]))

    def input_stmt(self, items):
        name = str(items[0])
        self.env[name] = input("> ")

    def inputnum_stmt(self, items):
        name = str(items[0])
        self.env[name] = int(input("> "))

    def inputtxt_stmt(self, items):
        name = str(items[0])
        self.env[name] = str(input("> "))

    # EXPRESSÕES
    def add(self, items):
        return self._resolve(items[0]) + self._resolve(items[1])

    def sub(self, items):
        return self._resolve(items[0]) - self._resolve(items[1])

    def mul(self, items):
        return self._resolve(items[0]) * self._resolve(items[1])

    def div(self, items):
        return self._resolve(items[0]) / self._resolve(items[1])

    def is_(self, items):
        return self._resolve(items[0]) == self._resolve(items[1])

    def aint(self, items):
        return self._resolve(items[0]) != self._resolve(items[1])

    def number(self, token):
        return int(token[0])

    def string(self, token):
        return str(token[0])[1:-1]

    def var(self, token):
        return str(token[0])

    def _resolve(self, val):
        if isinstance(val, str):
            return self.env.get(val, val)
        return val

    # CONTROLE DE FLUXO
    def when_stmt(self, items):
        if self._resolve(items[0]):
            for stmt in items[1:]:
                self._execute(stmt)

    def loop_spin(self, items):
        while self._resolve(items[0]):
            for stmt in items[1:]:
                self._execute(stmt)
                if self.returning:
                    break

    def loop_loopy(self, items):
        while True:
            for stmt in items:
                self._execute(stmt)
                if self.returning:
                    return

    def loop_breaky(self, _):
        self.returning = True

    def loop_skipit(self, _):
        pass

    # FUNÇÕES
    def func_decl(self, items):
        name = str(items[0])
        self.functions[name] = items[1:]

    def func_call(self, items):
        name = str(items[0])
        body = self.functions.get(name)
        if body:
            for stmt in body:
                self._execute(stmt)
                if self.returning:
                    break
        return self.return_value

    def return_stmt(self, items):
        self.return_value = self._resolve(items[0])
        self.returning = True

    # LISTAS
    def pack_decl(self, items):
        name = str(items[0])
        values = [self._resolve(val) for val in items[1:]]
        self.env[name] = values

    def pack_add(self, items):
        name = str(items[0])
        value = self._resolve(items[1])
        self.env[name].append(value)

    def pack_get(self, items):
        name = str(items[0])
        index = self._resolve(items[1])
        return self.env[name][index]

    # DICIONÁRIOS
    def box_decl(self, items):
        name = str(items[0])
        box = {}
        for pair in items[1:]:
            key = str(pair[0])
            val = self._resolve(pair[1])
            box[key] = val
        self.env[name] = box

    def box_put(self, items):
        box = str(items[0])
        key = str(items[1])
        value = self._resolve(items[2])
        self.env[box][key] = value

    def box_get(self, items):
        box = str(items[0])
        key = str(items[1])
        return self.env[box][key]

    # ESPERA
    def wait_stmt(self, items):
        time.sleep(self._resolve(items[0]))

    # CONVERSÃO
    def convert(self, items):
        name = str(items[0])
        target_type = str(items[1])
        value = self.env.get(name)

        if target_type == "int":
            self.env[name] = int(value)
        elif target_type == "str":
            self.env[name] = str(value)

    # USO DE BIBLIOTECAS
    def use_stmt(self, items):
        libname = str(items[0])
        lib_path = os.path.join("libs", libname + ".snask")

        if os.path.exists(lib_path):
            with open(lib_path, "r", encoding="utf-8") as f:
                code = f.read()
                tree = self.parser.parse(code)
                self.transform(tree)
        else:
            print(f"Biblioteca '{libname}' não encontrada.")

    # EXECUÇÃO DE BLOCOS
    def _execute(self, stmt):
        if hasattr(stmt, "data"):
            method = getattr(self, stmt.data, None)
            if method:
                method(stmt.children)
