import os
import zipfile
import urllib.request
import shutil
import sys
import subprocess

URL_ZIP = "https://snask.onrender.com/download/font"  # <-- coloque a URL certa aqui
DEST_FOLDER = "C:\\Snask"
TMP_ZIP = "snask_tmp.zip"

def download_snask():
    print("📥 Baixando o Snask...")
    urllib.request.urlretrieve(URL_ZIP, TMP_ZIP)

def extrair_zip():
    print("📦 Extraindo arquivos...")
    with zipfile.ZipFile(TMP_ZIP, 'r') as zip_ref:
        zip_ref.extractall(DEST_FOLDER)

def adicionar_ao_path():
    print("🛠️ Adicionando ao PATH...")
    path = os.environ.get("PATH", "")
    if DEST_FOLDER not in path:
        subprocess.run(f'setx PATH "{path};{DEST_FOLDER}"', shell=True)

def main():
    try:
        download_snask()
        extrair_zip()
        adicionar_ao_path()
        print(f"✅ Snask instalado em {DEST_FOLDER}")
        print("🔁 Reinicie o terminal para usar 'snask' e 'snaskget'")
    except Exception as e:
        print(f"❌ Erro: {e}")
    finally:
        if os.path.exists(TMP_ZIP):
            os.remove(TMP_ZIP)

if __name__ == "__main__":
    main()
