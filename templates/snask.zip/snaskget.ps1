param (
    [string]$nome
)

$snaskDir = "C:\Snask"
$libsDir = "$snaskDir\libs"

if (-not (Test-Path $libsDir)) {
    New-Item -ItemType Directory -Path $libsDir | Out-Null
}

Write-Host "Baixando biblioteca $nome..."

# Remove a extensão .snask do nome
$baseName = $nome -replace '\.snask$', ''

try {
    $resp = Invoke-WebRequest -Uri "https://snask.onrender.com/api/lib/$baseName.snask" -UseBasicParsing
    if ($resp.StatusCode -eq 200) {
        $data = $resp.Content | ConvertFrom-Json
        $filePath = "$libsDir\$nome"
        [System.IO.File]::WriteAllText($filePath, $data.code, [System.Text.Encoding]::UTF8)
        Write-Host "Biblioteca $nome baixada com sucesso em $filePath"
    } else {
        Write-Host "Biblioteca '$nome' não encontrada."
    }
} catch {
    Write-Host "Erro ao conectar ao servidor SnaskGet."
}
