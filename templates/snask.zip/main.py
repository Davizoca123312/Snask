import sys
import os
from lark import Lark
from snask_interpreter import SnaskInterpreter

def carregar_gramatica(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        return f.read()

def carregar_bibliotecas(pasta, parser, interpreter):
    if os.path.exists(pasta):
        for arquivo in os.listdir(pasta):
            if arquivo.endswith(".snask"):
                caminho = os.path.join(pasta, arquivo)
                with open(caminho, "r", encoding="utf-8") as f:
                    codigo = f.read()
                    arvore = parser.parse(codigo)
                    interpreter.transform(arvore)
                print(f"✅ Biblioteca carregada: {arquivo}")
    else:
        print("📁 Pasta 'libs' não encontrada. Nenhuma biblioteca carregada.")

def executar_arquivo(path, parser, interpreter):
    with open(path, "r", encoding="utf-8") as f:
        codigo = f.read()
    arvore = parser.parse(codigo)
    interpreter.transform(arvore)

def main():
    if len(sys.argv) < 2:
        print("Uso: ./snask arquivo.snask")
        sys.exit(1)

    input_file = sys.argv[1]

    # Carrega a gramática e inicializa o parser
    gramatica = carregar_gramatica("grammar.lark")
    parser = Lark(gramatica, parser="lalr")
    interpreter = SnaskInterpreter()

    # Carrega bibliotecas de Snask
    carregar_bibliotecas("libs", parser, interpreter)

    # Executa o código principal
    executar_arquivo(input_file, parser, interpreter)

if __name__ == "__main__":
    main()
