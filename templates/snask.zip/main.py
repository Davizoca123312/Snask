import sys
import os
from lark import Lark
from snask_interpreter import SnaskInterpreter

def carregar_gramatica(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        return f.read()

def carregar_bibliotecas(pasta, parser, interpreter):
    if os.path.exists(pasta):
        for arquivo in os.listdir(pasta):
            if arquivo.endswith(".snask"):
                caminho = os.path.join(pasta, arquivo)
                with open(caminho, "r", encoding="utf-8") as f:
                    codigo = f.read()
                    arvore = parser.parse(codigo)
                    interpreter.transform(arvore)
                print(f"✅ Biblioteca carregada: {arquivo}")
    else:
        print("📁 Pasta 'libs' não encontrada. Nenhuma biblioteca carregada.")


import traceback
import sys
import os
from lark import Lark, UnexpectedInput
from snask_interpreter import SnaskInterpreter

def executar_codigo(code, parser, interpreter):
    try:
        tree = parser.parse(code)
        interpreter.transform(tree)
    except UnexpectedInput as e:
        print("\n🚨 ERRO DE SINTAXE NO CÓDIGO 🚨")
        print(f"Arquivo: {input_file}")
        print(f"Linha: {e.line}, Coluna: {e.column}")
        print(f"Erro próximo de: {e.get_context(code).strip()}")
        print(f"Detalhes: {e.__class__.__name__}: {str(e).splitlines()[0]}")
        print("\nCorrija o erro e tente novamente.")
        sys.exit(1)
    except Exception as e:
        print("\n🚨 ERRO INTERNO 🚨")
        print(f"Erro: {e.__class__.__name__}: {str(e)}")
        sys.exit(1)

def main():
    global input_file
    if len(sys.argv) < 2:
        print("Uso: ./snask arquivo.snask")
        sys.exit(1)

    input_file = sys.argv[1]

    with open("grammar.lark", "r", encoding="utf-8") as f:
        grammar = f.read()

    parser = Lark(grammar, parser="lalr")
    interpreter = SnaskInterpreter()

    if os.path.exists("libs"):
        for filename in os.listdir("libs"):
            if filename.endswith(".snask"):
                with open(os.path.join("libs", filename), "r", encoding="utf-8") as libfile:
                    lib_code = libfile.read()
                    executar_codigo(lib_code, parser, interpreter)
    else:
        print("📁 Pasta 'libs' não encontrada. Nenhuma biblioteca carregada.")

    with open(input_file, "r", encoding="utf-8") as f:
        code = f.read()

    executar_codigo(code, parser, interpreter)

if __name__ == "__main__":
    main()
