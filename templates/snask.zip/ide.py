import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess
import os

class SnaskIDE:
    def __init__(self, root):
        self.root = root
        self.root.title("Snask IDE")

        # Editor de texto
        self.editor = tk.Text(root, wrap="word", font=("Consolas", 12))
        self.editor.pack(expand=1, fill="both")

        # Área de saída
        self.output = tk.Text(root, height=10, bg="#111", fg="#0f0")
        self.output.pack(fill="x")

        # Botões
        btn_frame = tk.Frame(root)
        btn_frame.pack(fill="x")
        tk.Button(btn_frame, text="Abrir", command=self.abrir).pack(side="left")
        tk.Button(btn_frame, text="Salvar", command=self.salvar).pack(side="left")
        tk.Button(btn_frame, text="Executar", command=self.executar).pack(side="right")

    def abrir(self):
        path = filedialog.askopenfilename(filetypes=[("Arquivos Snask", "*.snask")])
        if path:
            with open(path, "r", encoding="utf-8") as f:
                self.editor.delete("1.0", tk.END)
                self.editor.insert("1.0", f.read())

    def salvar(self):
        path = filedialog.asksaveasfilename(defaultextension=".snask", filetypes=[("Arquivos Snask", "*.snask")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.editor.get("1.0", tk.END))

    def executar(self):
        temp_path = "temp_exec.snask"
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(self.editor.get("1.0", tk.END))

        self.output.delete("1.0", tk.END)
        try:
            result = subprocess.check_output(["python", "main.py", temp_path], stderr=subprocess.STDOUT, text=True)
            self.output.insert("1.0", result)
        except subprocess.CalledProcessError as e:
            self.output.insert("1.0", e.output)

# Inicializar
if __name__ == "__main__":
    root = tk.Tk()
    app = SnaskIDE(root)
    root.mainloop()
